# h5news
信息流新闻H5
# 加载依赖
```
cnpm install
````
#安装gulp
```
cnpm install -g gulp
```
# 创建渠道
```
gulp build
```
# 添加渠道配置
```
gulp config
```
· 具体的配置请看源码，写的很清楚了
